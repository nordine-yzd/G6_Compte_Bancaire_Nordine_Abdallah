package projetCompteBancaire;

import java.util.* ;


public class Test {

	private int annee ;
	private int anneeActuelle ;
	 	
	public Test(int annee, int anneeActuelle) {
		this.annee = annee;
		this.anneeActuelle = anneeActuelle;
	}
	
	
	public int getAnnee() {
		return annee;
	}
	public void setAnnee(int annee) {
		this.annee = annee;
	}
	public int getAnneeActuelle() {
		return anneeActuelle;
	}
	public void setAnneeActuelle(int anneeActuelle) {
		this.anneeActuelle = anneeActuelle;
	}
	
	
	public void afficherAge () {
		int age = anneeActuelle-annee ;
		System.out.println("si je suis n�� en " + this.annee + "et que nous somme en "+this.anneeActuelle+ "alors j'aurai " + age);
	}
	
	
	


	public static void main(String[] args) {
	
	@SuppressWarnings("resource")
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Veuillez saisir une annee :");
	int anos = sc.nextInt();
	System.out.println("Vous avez saisi : " + anos);
	
	
		
		Test test1 = new Test(anos,2021);
		test1.afficherAge();
	}
}
